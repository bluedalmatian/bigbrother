<?php
##THIS FILE IS GENERATED AUTOMATICALLY BY bigbrotherd##
$DAEMONPID=704;
$GLOBALCONFFILEPATH='/usr/local/bigbrother/bigbrother.conf';
$BBVERSION=0.5;
?>
